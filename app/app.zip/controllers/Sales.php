<?php defined('BASEPATH') or exit('No direct script access allowed');

use WpOrg\Requests\Requests as Api;

use function PHPSTORM_META\map;

class Sales extends MY_Controller
{

    function __construct()
    {
        parent::__construct();

        if (!$this->loggedIn) {
            $this->session->set_flashdata('warning', lang('access_denied'));
            redirect('logout');
        }

        $this->load->library(['form_validation']);
        $this->load->model(['items_model', 'warehouses_model', 'sales_model']);

        ini_set('display_errors', 1);
    }

    public function index()
    {

        set_cookie('ci_csrf_token', 'ci_csrf_token', 128000);

        $this->data['error'] = validation_errors() ? validation_errors() : $this->session->flashdata('error');
        $this->data['page_title'] = lang('Sales');
        $this->page_construct('sales/index', $this->data);

        if (!empty($_SESSION['message'])) {
            unset($_SESSION['message']);
        }
    }

    public function get_sales($alerts = NULL)
    {
        // $links = "<div class='text-center'>";

        // if ($this->Admin) {



        //     $links .=
        //         "    

        //         <!-- delete sales button -->
        //         <a href='#' class='btn btn-danger btn-xs-block tip po' title='<b>" 
        //         . lang("delete sales ?") 
        //         . "</b>' 

        //             data-content=\"
        //                 <p>"
        //                  . lang('r_u_sure') 
        //                  . "</p>
        //             <a class='btn btn-danger po-delete' href='" 
        //             . site_url('sales/deleteSales/$1') 
        //             . "'>"
        //             . lang('i_m_sure') 
        //             . "
        //             </a> 
        //                 <button class='btn po-close'>" . lang('no') .
        //         "</button>\"  rel='popover'>
        //         <!--   <i class=\"fa fa-trash-o\"></i>-->
        //             <span>Delete</span>
        //         </a>

        //         </br>
        //         </br>

        //         <!-- update status packing button -->

        //         <a href='#' class='btn btn-warning  btn-xs-block tip po' title='<b>" . lang("Update Status Packing") . "</b>' 
        //         data-content=\"
        //             <p>" . lang('r_u_sure') . "</p>
        //             <a class='btn btn-info po-delete' href='" . site_url('sales/update_status_packing/$1') . "'>" . lang('i_m_sure') . "
        //             </a> 
        //             <button class='btn po-close'>" . lang('no') .
        //         "</button>\"  rel='popover'>
        //             <span>Update Status Packing</span>
        //         </a>



        //     ";
        // }
        // $links .= "</div>";

        $this->load->library('datatables');
        $this->datatables
            ->select("id, order_no, awb_no, no_referensi, courier, status, service, type, created_date, dispatch_date, delivered_date, returned_date, package_price, insurance, shipping_price, shipping_cashback, cod_value, cod_fee, cod_disbursement, shipper_name, shipper_phone, shipper_address, shipper_city, shipper_subdistrict, shipper_zip_code, receiver_name, receiver_phone, receiver_address, receiver_city, receiver_subdistrict, receiver_zip_code, goods_description, quantity, dimension_size, shipping_note, last_tracking_status, status_packing")
            ->from('sales');
        $this->datatables->add_column("Actions", "id");
        // $this->datatables->add_column("Actions", $links, "id");
        echo $this->datatables->generate();
    }

    public function add()
    {
        $this->data['error'] = validation_errors() ? validation_errors() : $this->session->flashdata('error');
        $this->data['page_title'] = lang('add');
        $this->page_construct('sales/add', $this->data);
    }

    public function addSales()
    {
        $link = $this->input->post('link');
        $data = "";
        if (!empty($link)) {
            $data = $link;
        } else {
            $this->session->set_flashdata('error', lang("Link is required"));
            redirect("sales");
        }

        if ($this->sales_model->addSales($data)) {
            $this->session->set_flashdata('message', lang("sales_added"));
            redirect('sales');
        } else {
            $this->session->set_flashdata('message', lang("Gagal menambahkan data"));
            redirect('sales');
        }
    }

    public function deleteSales($id = null)
    {
        if (!$this->Admin) {
            $this->session->set_flashdata('warning', lang('access_denied'));
            redirect("sales");
        }
        if ($this->sales_model->delete($id)) {
            $this->session->set_flashdata('message', lang("item_deleted"));
            redirect("sales");
        } else {
            $this->session->set_flashdata('error', lang("delete_failed"));
            redirect("sales");
        }
    }

    public function update_status_packing($id = null)
    {


        $query = $this->sales_model->update_status_packing($id);
        if ($query) {
            $this->session->set_flashdata('message', lang("Status Packing Updated"));
            redirect("sales");
        } else {
            $this->session->set_flashdata('error', lang("Status Packing Failed Update"));
            redirect("sales");
        }
    }


    function alerts()
    {
        $data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');
        $this->data['page_title'] = lang('stock_alert');
        $bc = array(array('link' => '#', 'page' => lang('stock_alert')));
        $meta = array('page_title' => lang('stock_alert'), 'bc' => $bc);
        $this->page_construct('items/alerts', $this->data, $meta);
    }

    function get_alerts()
    {

        $this->load->library('datatables');
        $this->datatables->select($this->db->dbprefix('products') . ".id as pid, " . $this->db->dbprefix('products') . ".image as image, " . $this->db->dbprefix('products') . ".code as code, " . $this->db->dbprefix('products') . ".name as pname, type, " . $this->db->dbprefix('categories') . ".name as cname, quantity, alert_quantity, tax, tax_method, cost, price", FALSE)
            ->join('categories', 'categories.id=products.category_id')
            ->from('products')
            ->where('quantity < alert_quantity', NULL, FALSE)
            ->group_by('products.id');
        $this->datatables->add_column("Actions", "<div class='text-center'><a href='#' class='btn btn-xs btn-primary ap tip' data-id='$1' title='" . lang('add_to_purcahse_order') . "'><i class='fa fa-plus'></i></a></div>", "pid");
        $this->datatables->unset_column('pid');
        echo $this->datatables->generate();
    }
}
