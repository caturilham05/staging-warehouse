<?php defined('BASEPATH') or exit('No direct script access allowed');

use WpOrg\Requests\Requests as Api;

use function PHPSTORM_META\map;

class Sales_model extends CI_Model
{



    public function __construct()
    {
        parent::__construct();
    }

    public function addSales(string $data)
    {
        return $this->insertBatch($data);
    }

    public function getSales()
    {
        return $this->db->get('sales')->result_array();
    }

    public function insertBatch(string $data)
    {
        $this->db->trans_begin();

        $api = Api::get($data);
       
        $api = json_decode($api->body);
        $key  = key($api);
        $array_data = $api->$key;
        $new_data = [];
        $data_post = [];

        foreach ($array_data as $value) {
            $key = array_keys((array)$value);
            $key = preg_replace('/\s.*/', '', $key);
            $new_data[] = array_combine($key, (array)$value);
        }


        $check_data = $this->db->select(['order_no', 'awb_no'])->from('sales')->get()->result_array();

        foreach ($new_data as $v) {

            if (in_array($v['orderNo'], array_column($check_data, 'order_no')) && in_array($v['awbNo'], array_column($check_data, 'awb_no'))) {
                continue;
            }
            $data_post[] = [
                'order_no' => $v['orderNo'],
                'awb_no' => $v['awbNo'],
                'no_referensi' => $v['noReferensi'],
                'courier'   => $v['courier'], //index 4
                'status'    => $v['status'],
                'service' => $v['service'], //index 6
                'type'  => $v['type'],
                'created_date' => date('Y-m-d H:i:s', strtotime($v['createdDate'])), //index 8
                'dispatch_date' => $v['dispatchDate'],
                'delivered_date' => $v['deliveredDate'],
                'returned_date' => $v['returnedDate'],
                'package_price' => $v['packagePrice'], //index 12
                'insurance' => $v['insurance'],
                'shipping_price' => $v['shippingPrice'],
                'shipping_cashback' => $v['shippingCashback'],
                'cod_value' => $v['codValue'], //index 16
                'cod_fee' => $v['codFee'],
                'cod_disbursement' => $v['codDisbursement'],
                'shipper_name' => $v['shipperName'], //index 19
                'shipper_phone' => $v['shipperPhone'],
                'shipper_address' => $v['shipperAddress'], //index 21
                'shipper_city' => $v['shipperCity'],
                'shipper_subdistrict' => $v['shipperSubdistrict'],
                'shipper_zip_code' => $v['shipperZipCode'],
                'receiver_name' => $v['receiverName'], //index 25
                'receiver_phone' => $v['receiverPhone'],
                'receiver_address' => $v['receiverAddress'],
                'receiver_city' => $v['receiverCity'],
                'receiver_subdistrict' => $v['receiverSubdistrict'],
                'receiver_zip_code' => $v['receiverZipCode'], //index 30
                'goods_description' => $v['goodsDescription'],
                'quantity' => $v['quantity'],
                'weight' => $v['weight'],
                'dimension_size' => $v['lengthXWidthXHeight'],
                'shipping_note' => $v['shippingNote'],
                'last_tracking_status' => $v['lastTrackingStatus'],
            ];
        }

        $this->db->insert_batch('sales', $data_post);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();

            return false;
        } else {
            $this->db->trans_commit();
            return true;
            // $this->session->set_flashdata('message', lang("sales_added"));
            // redirect('sales');
        }
    }

    public function delete($id)
    {

        return $this->db->where('id', $id)->delete('sales');
    }

    public function update_status_packing($id)
    {
        return $this->db->where('id', $id)->update('sales', ['status_packing' => 'sent']);
    }
}
